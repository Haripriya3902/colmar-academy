
# Colmar Academy Landing Page

This project is a basic landing page for Colmar Academy, built with HTML and CSS based on a provided wireframe.

## Folder Structure

```
colmar-academy/
├── index.html
├── css/
│   └── styles.css
├── images/
└── README.md
```

## How to Use

1. Open `index.html` in your browser to view the page.
2. Edit the HTML/CSS files as needed to customize the design.
3. Add image assets to the `images/` folder for full functionality.

## Live Preview

To run this locally with Live Server (recommended):
- Install the Live Server extension in VS Code.
- Right-click `index.html` > "Open with Live Server".
